document.addEventListener('DOMContentLoaded', () => {
    // DOM elements
    const permissionPopup = document.getElementById('permission-popup');
    const useCameraBtn = document.getElementById('use-camera');
    const viewOnlyBtn = document.getElementById('view-only');
    const container = document.getElementById('container');
    const arView = document.getElementById('ar-view');
    const modelContainer = document.getElementById('model-container');
    const fallbackContainer = document.getElementById('fallback-container');

    // Three.js variables
    let scene, camera, renderer, model, controls;
    let fallbackScene, fallbackCamera, fallbackRenderer, fallbackModel, fallbackControls;

    // Event listeners for buttons
    useCameraBtn.addEventListener('click', initARView);
    viewOnlyBtn.addEventListener('click', initFallbackView);

    function initFallbackView() {
        permissionPopup.classList.add('hidden');
        container.classList.remove('hidden');
        fallbackContainer.classList.remove('hidden');

        // Set up scene
        fallbackScene = new THREE.Scene();
        fallbackScene.background = new THREE.Color(0x222222);

        // Set up camera
        fallbackCamera = new THREE.PerspectiveCamera(
            60, 
            window.innerWidth / window.innerHeight, 
            0.1, 
            1000
        );
        fallbackCamera.position.z = 3;

        // Set up renderer
        fallbackRenderer = new THREE.WebGLRenderer({ antialias: true });
        fallbackRenderer.setPixelRatio(window.devicePixelRatio);
        fallbackRenderer.setSize(window.innerWidth, window.innerHeight);
        fallbackContainer.appendChild(fallbackRenderer.domElement);

        // Add lights
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
        fallbackScene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(1, 1, 1);
        fallbackScene.add(directionalLight);

        // Load model
        const loader = new THREE.GLTFLoader();
        loader.load(
            'models/dababy.glb',
            (gltf) => {
                fallbackModel = gltf.scene;
                
                // Center and scale model
                const box = new THREE.Box3().setFromObject(fallbackModel);
                const center = box.getCenter(new THREE.Vector3());
                fallbackModel.position.sub(center);
                const size = box.getSize(new THREE.Vector3()).length();
                const scale = 2.0 / size;
                fallbackModel.scale.set(scale, scale, scale);
                
                fallbackScene.add(fallbackModel);
            },
            undefined,
            (error) => {
                console.error('Error loading model:', error);
            }
        );

        // Set up controls
        fallbackControls = new THREE.OrbitControls(fallbackCamera, fallbackRenderer.domElement);
        fallbackControls.enableDamping = true;
        fallbackControls.dampingFactor = 0.05;
        fallbackControls.screenSpacePanning = false;
        fallbackControls.maxPolarAngle = Math.PI;
        fallbackControls.minDistance = 1;
        fallbackControls.maxDistance = 10;
        fallbackControls.enableTouch = true;

        // Handle window resize
        window.addEventListener('resize', () => {
            fallbackCamera.aspect = window.innerWidth / window.innerHeight;
            fallbackCamera.updateProjectionMatrix();
            fallbackRenderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            fallbackControls.update();
            fallbackRenderer.render(fallbackScene, fallbackCamera);
        }
        animate();
    }

    function initARView() {
        permissionPopup.classList.add('hidden');
        container.classList.remove('hidden');
        arView.classList.remove('hidden');
        modelContainer.classList.remove('hidden');

        // Try to access camera
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then((stream) => {
                arView.srcObject = stream;
                arView.play();
                initARScene();
            })
            .catch((err) => {
                console.error("Camera error:", err);
                alert("Couldn't access camera. Switching to view-only mode.");
                initFallbackView();
            });
    }

    function initARScene() {
        // Set up scene with video background
        scene = new THREE.Scene();
        scene.background = new THREE.VideoTexture(arView);

        // Set up camera
        camera = new THREE.PerspectiveCamera(
            60, 
            window.innerWidth / window.innerHeight, 
            0.1, 
            1000
        );
        camera.position.set(0, 1.5, 3);

        // Set up renderer
        renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setPixelRatio(window.devicePixelRatio);
        renderer.setSize(window.innerWidth, window.innerHeight);
        modelContainer.appendChild(renderer.domElement);

        // Add lights
        scene.add(new THREE.AmbientLight(0xffffff, 0.8));
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(1, 1, 1);
        scene.add(directionalLight);

        // Load model
        const loader = new THREE.GLTFLoader();
        loader.load(
            'models/dababy.glb',
            (gltf) => {
                model = gltf.scene;
                model.scale.set(3, 3, 3);
                model.position.set(0, 0, 0);
                scene.add(model);
            },
            undefined,
            (error) => {
                console.error('Error loading model:', error);
            }
        );

        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        }
        animate();
    }
});