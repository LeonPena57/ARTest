document.addEventListener('DOMContentLoaded', () => {
    const DEBUG = true;

    // DOM elements
    const video = document.getElementById('ar-view');
    const modelContainer = document.getElementById('model-container');
    const loadingUI = document.getElementById('loading');
    const popupUI = document.getElementById('model-popup');
    const popupButton = document.getElementById('observe-button');
    const previewContainer = document.getElementById('preview-container');
    const mainContainer = document.getElementById('container');

    // Three.js variables
    let scene, camera, renderer, model, controls;
    let previewScene, previewCamera, previewRenderer, previewModel;

    // Show popup first
    popupButton.addEventListener('click', () => {
        popupUI.style.display = 'none';
        mainContainer.classList.remove('hidden');
        initARView();
    });

    function initPreview() {
        if (DEBUG) console.log("Initializing model preview...");

        previewScene = new THREE.Scene();
        previewCamera = new THREE.PerspectiveCamera(45, 1, 0.1, 10);
        previewCamera.position.set(0, 0.5, 1.5);

        previewRenderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        previewRenderer.setSize(150, 150);
        previewContainer.appendChild(previewRenderer.domElement);

        const light = new THREE.AmbientLight(0xffffff, 0.8);
        previewScene.add(light);

        const loader = new THREE.GLTFLoader();
        loader.load('models/dababy.glb', (gltf) => {
            previewModel = gltf.scene;
            previewModel.scale.set(0.5, 0.5, 0.5);  // Adjust scale for preview size
            previewModel.position.set(0, 0, 0);   // Center the model
            previewScene.add(previewModel);
            animatePreview();
        });

        function animatePreview() {
            requestAnimationFrame(animatePreview);
            if (previewModel) previewModel.rotation.y += 0.01;
            previewRenderer.render(previewScene, previewCamera);
        }
    }

    function initARView() {
        if (DEBUG) console.log("Initializing AR View...");

        setupCameraFeed();
        init3DScene();
        loadModel('models/dababy.glb');
    }

    function setupCameraFeed() {
        const constraints = {
            video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
        };

        navigator.mediaDevices.getUserMedia(constraints)
            .then(stream => {
                video.srcObject = stream;
                video.play();
            })
            .catch(err => {
                console.error("Camera error:", err);
                alert("Enable camera permissions and use HTTPS/localhost.");
            });
    }

    function init3DScene() {
        scene = new THREE.Scene();
        scene.background = new THREE.VideoTexture(video);

        camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
        camera.position.set(0, 1.5, 3); // Adjust camera height and distance
        scene.add(camera);

        scene.add(new THREE.AmbientLight(0xffffff, 0.8));
        const light = new THREE.DirectionalLight(0xffffff, 1);
        light.position.set(0, 2, 2);
        scene.add(light);

        renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        modelContainer.appendChild(renderer.domElement);

        controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.25;
        controls.enableZoom = true;

        window.addEventListener('resize', onWindowResize);
        animate();
    }

    function loadModel(url) {
        if (DEBUG) console.log(`Loading model: ${url}`);
        loadingUI.style.display = 'block';

        const loader = new THREE.GLTFLoader();
        loader.load(
            url,
            gltf => {
                model = gltf.scene;
                model.scale.set(3, 3, 3);  // Adjust scale for the AR view
                model.position.set(0, 0.2, 0);  // Adjust position for proper centering
                scene.add(model);

                loadingUI.style.display = 'none';
                console.log("Model loaded successfully!");
            },
            undefined,
            error => {
                console.error("Model load failed:", error);
                loadingUI.style.display = 'none';
            }
        );
    }

    function onWindowResize() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }

    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }

    initPreview();
});
